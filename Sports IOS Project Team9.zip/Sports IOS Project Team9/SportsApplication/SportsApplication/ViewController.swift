//
//  ViewController.swift
//  SportsApplication
//
//  Created by MacOSSierra on 2/16/21.
//  Copyright © 2021 ITI. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

