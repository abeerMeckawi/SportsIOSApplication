//
//  Leagues.swift
//  SportsApplication
//
//  Created by MacOSSierra on 2/28/21.
//  Copyright © 2021 ITI. All rights reserved.
//

import Foundation

class League{
    
    var leagueName :String = ""
    var leagueImg :String = ""
    var leaguevid :String = ""
    
}
