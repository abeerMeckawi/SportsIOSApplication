//
//  Sports.swift
//  SportsApplication
//
//  Created by MacOSSierra on 2/28/21.
//  Copyright © 2021 ITI. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class Sports{
    
    var sportName : String = " "
    var sportImage : String = " "
    var sportId : String = " "

}


