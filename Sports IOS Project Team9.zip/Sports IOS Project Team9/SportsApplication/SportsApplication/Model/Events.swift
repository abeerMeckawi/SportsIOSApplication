//
//  Events.swift
//  SportsApplication
//
//  Created by MacOSSierra on 2/28/21.
//  Copyright © 2021 ITI. All rights reserved.
//

import Foundation

class Event{
    
    var eventName : String = "";
    var eventDate : String = "";
    var eventTime : String = "";
    var homeTeam : String = "";
    var SecondTeam : String = "";
    var HomeScore : String = "";
    var SecondScore : String = "";
    
}
