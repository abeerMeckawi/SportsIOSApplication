//
//  Teams.swift
//  SportsApplication
//
//  Created by MacOSSierra on 3/2/21.
//  Copyright © 2021 ITI. All rights reserved.
//

import Foundation
class Team{
    
    var teamId : String = ""
    var teamName : String = ""
    var teamBadge : String = ""
    var teamLeague : String = " "
    var teamStadium : String = ""
    var teamStadiumImg : String = ""
    
}
