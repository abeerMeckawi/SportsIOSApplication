//
//  TeamCollectionReusableView.swift
//  SportsApplication
//
//  Created by MacOSSierra on 3/1/21.
//  Copyright © 2021 ITI. All rights reserved.
//

import UIKit

class TeamCollectionReusableView: UICollectionReusableView {
        
}
