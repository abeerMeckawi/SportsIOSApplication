//
//  SportsCollectionViewCell.swift
//  SportsApplication
//
//  Created by MacOSSierra on 2/16/21.
//  Copyright © 2021 ITI. All rights reserved.
//

import UIKit

class SportsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageSports: UIImageView!
    
    @IBOutlet weak var lblSports: UILabel!
}
