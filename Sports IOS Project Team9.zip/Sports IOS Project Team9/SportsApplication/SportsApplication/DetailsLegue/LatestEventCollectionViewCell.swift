//
//  LatestEventCollectionViewCell.swift
//  SportsApplication
//
//  Created by MacOSSierra on 3/1/21.
//  Copyright © 2021 ITI. All rights reserved.
//

import UIKit

class LatestEventCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var lblHomeT: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var lblSecondT: UILabel!
    
    @IBOutlet weak var lblHomeScore: UILabel!
    
    @IBOutlet weak var lblSecondScore: UILabel!
    
    @IBOutlet weak var lblTime: UILabel!
}
