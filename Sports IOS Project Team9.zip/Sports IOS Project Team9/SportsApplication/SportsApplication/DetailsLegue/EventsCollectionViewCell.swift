//
//  EventsCollectionViewCell.swift
//  SportsApplication
//
//  Created by MacOSSierra on 2/27/21.
//  Copyright © 2021 ITI. All rights reserved.
//

import UIKit

class EventsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var lblEvent: UILabel!
    
    @IBOutlet weak var lbllDate: UILabel!
    
    @IBOutlet weak var lblTime: UILabel!
}
